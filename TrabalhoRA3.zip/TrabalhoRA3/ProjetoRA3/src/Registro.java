public class Registro {
    public int codigo;

    public Registro(int codigo) {
        this.codigo = codigo;
    }
}
